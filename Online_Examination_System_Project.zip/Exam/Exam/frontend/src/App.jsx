
import { useEffect, useState } from "react";
import keycloak from "./keycloak";

import {
  getProfile,
  getExams,
  createExam,
  getQuestions,
  addQuestion,
  submitExam,
  getMyResults,
  getAdminDashboard,
} from "./api";

export default function App() {
  const [ready, setReady] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [profile, setProfile] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const [exams, setExams] = useState([]);
  const [results, setResults] = useState([]);
  const [adminData, setAdminData] = useState(null);
  const [selectedExam, setSelectedExam] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [submission, setSubmission] = useState(null);

  const [examForm, setExamForm] = useState({
    title: "",
    description: "",
    duration_minutes: 30,
    is_published: true,
  });

  const [questionForm, setQuestionForm] = useState({
    question_text: "",
    option_a: "",
    option_b: "",
    option_c: "",
    option_d: "",
    correct_option: "A",
    marks: 1,
  });

  const roles = keycloak.realmAccess?.roles || [];
  const isAdmin = roles.includes("admin");
  const username =
    profile?.username ||
    keycloak.tokenParsed?.preferred_username ||
    "User";

  useEffect(() => {
    let active = true;

    keycloak
      .init({
        onLoad: "check-sso",
        pkceMethod: "S256",
        checkLoginIframe: false,
      })
      .then(async (loggedIn) => {
        if (!active) return;

        setAuthenticated(loggedIn);

        if (loggedIn) {
          try {
            const user = await getProfile(keycloak);
            if (active) setProfile(user);
          } catch (err) {
            if (active) setError(err.message);
          }
        }

        if (active) setReady(true);
      })
      .catch((err) => {
        console.error("Keycloak initialization failed:", err);
        if (active) {
          setError("Could not connect to Keycloak. Check your Keycloak service.");
          setReady(true);
        }
      });

    return () => {
      active = false;
    };
  }, []);

  async function refreshExams() {
    const data = await getExams(keycloak);
    setExams(Array.isArray(data) ? data : []);
  }

  async function refreshResults() {
    const data = await getMyResults(keycloak);
    setResults(Array.isArray(data) ? data : data?.results || []);
  }

  async function refreshAdminData() {
    const data = await getAdminDashboard(keycloak);
    setAdminData(data);
  }

  async function loadDashboard() {
    setError("");
    setNotice("");

    try {
      const user = await getProfile(keycloak);
      setProfile(user);
      await refreshExams();

      if (isAdmin) {
        await refreshAdminData();
      }
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    if (ready && authenticated) {
      loadDashboard();
    }
    // Load initial data after Keycloak initialization.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, authenticated]);

  async function login() {
    setError("");
    await keycloak.login({
      redirectUri: window.location.origin,
    });
  }

  async function logout() {
    await keycloak.logout({
      redirectUri: window.location.origin,
    });
  }

  function showPage(nextPage) {
    setPage(nextPage);
    setError("");
    setNotice("");
    setSubmission(null);
    setSelectedExam(null);
    setQuestions([]);
    setAnswers({});
  }

  async function openExam(exam) {
    setError("");
    setNotice("");
    setSubmission(null);
    setAnswers({});
    setSelectedExam(exam);

    try {
      const data = await getQuestions(keycloak, exam.id);
      setQuestions(Array.isArray(data) ? data : []);
      setPage("take-exam");
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleCreateExam(event) {
    event.preventDefault();
    setError("");
    setNotice("");

    try {
      await createExam(keycloak, {
        ...examForm,
        duration_minutes: Number(examForm.duration_minutes),
      });

      setExamForm({
        title: "",
        description: "",
        duration_minutes: 30,
        is_published: true,
      });

      await refreshExams();
      await refreshAdminData();
      setNotice("Exam created successfully.");
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleAddQuestion(event) {
    event.preventDefault();
    setError("");
    setNotice("");

    if (!selectedExam) {
      setError("Select an exam first.");
      return;
    }

    try {
      await addQuestion(keycloak, selectedExam.id, {
        ...questionForm,
        marks: Number(questionForm.marks),
      });

      setQuestionForm({
        question_text: "",
        option_a: "",
        option_b: "",
        option_c: "",
        option_d: "",
        correct_option: "A",
        marks: 1,
      });

      await refreshExams();
      await refreshAdminData();
      setNotice("Question added successfully.");
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleSubmitExam(event) {
    event.preventDefault();
    setError("");

    if (!selectedExam || questions.length === 0) {
      setError("This exam does not have any questions.");
      return;
    }

    if (Object.keys(answers).length !== questions.length) {
      setError("Please answer every question before submitting.");
      return;
    }

    const confirmed = window.confirm(
      "Are you sure you want to submit your examination?"
    );

    if (!confirmed) return;

    try {
      const result = await submitExam(
        keycloak,
        selectedExam.id,
        answers
      );

      setSubmission(result);
      setNotice("Your examination has been submitted successfully.");
      await refreshResults();
    } catch (err) {
      setError(err.message);
    }
  }

  async function showResults() {
    setError("");

    try {
      if (isAdmin) {
        await refreshAdminData();
        setPage("admin-results");
      } else {
        await refreshResults();
        setPage("results");
      }
    } catch (err) {
      setError(err.message);
    }
  }

  if (!ready) {
    return (
      <div className="center-screen">
        <div className="spinner" />
        <p>Connecting to Online Examination System...</p>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="login-screen">
        <div className="login-card">
          <div className="logo">OE</div>
          <h1>Online Examination System</h1>
          <p>Login securely using your Keycloak account.</p>
          {error && <div className="error">{error}</div>}
          <button className="primary-button full" onClick={login}>
            Login with Keycloak
          </button>
          <p className="muted">Admin and student accounts are supported.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="app-shell">
      <header className="navbar">
        <div className="brand" onClick={() => showPage("dashboard")}>
          <span className="brand-logo">OE</span>
          <span>Online Examination</span>
        </div>

        <nav>
          <button onClick={() => showPage("dashboard")}>Dashboard</button>
          <button onClick={() => showPage("exams")}>Exams</button>
          <button onClick={showResults}>
            {isAdmin ? "All Results" : "My Results"}
          </button>
          {isAdmin && (
            <button onClick={() => showPage("admin")}>Admin</button>
          )}
        </nav>

        <div className="user-menu">
          <span className="role-badge">
            {isAdmin ? "ADMIN" : "STUDENT"}
          </span>
          <span>{username}</span>
          <button className="logout-button" onClick={logout}>
            Logout
          </button>
        </div>
      </header>

      <main className="container">
        {error && (
          <div className="error">
            {error}
            <button onClick={() => setError("")}>×</button>
          </div>
        )}

        {notice && (
          <div className="success">
            {notice}
            <button onClick={() => setNotice("")}>×</button>
          </div>
        )}

        {page === "dashboard" && (
          <section>
            <div className="welcome-banner">
              <div>
                <p className="eyebrow">
                  {isAdmin ? "ADMINISTRATOR PORTAL" : "STUDENT PORTAL"}
                </p>
                <h1>Welcome, {profile?.full_name || username}!</h1>
                <p>
                  {isAdmin
                    ? "Manage examinations, questions, and student results."
                    : "View your examinations and track your performance."}
                </p>
              </div>
              <div className="welcome-icon">
                {isAdmin ? "🛡️" : "🎓"}
              </div>
            </div>

            <div className="stats-grid">
              <StatCard
                title="Available Exams"
                value={exams.length}
                icon="📝"
              />
              <StatCard
                title={isAdmin ? "Registered Users" : "Your Results"}
                value={
                  isAdmin
                    ? adminData?.statistics?.users ?? 0
                    : results.length
                }
                icon="👥"
              />
              {isAdmin && (
                <StatCard
                  title="Questions"
                  value={adminData?.statistics?.questions ?? 0}
                  icon="❓"
                />
              )}
              <StatCard
                title={isAdmin ? "Total Results" : "Completed Exams"}
                value={
                  isAdmin
                    ? adminData?.statistics?.results ?? 0
                    : results.length
                }
                icon="🏆"
              />
            </div>

            <div className="panel">
              <h2>Quick actions</h2>
              <div className="action-grid">
                <button onClick={() => showPage("exams")}>
                  Browse examinations
                </button>
                {isAdmin && (
                  <button onClick={() => showPage("admin")}>
                    Manage examinations
                  </button>
                )}
                <button onClick={showResults}>View results</button>
              </div>
            </div>
          </section>
        )}

        {page === "exams" && (
          <section>
            <PageHeading
              title="Examinations"
              subtitle="Browse available examinations."
            />

            {exams.length === 0 ? (
              <EmptyState message="No examinations are currently available." />
            ) : (
              <div className="exam-grid">
                {exams.map((exam) => (
                  <article className="exam-card" key={exam.id}>
                    <div className="exam-icon">📚</div>
                    <h3>{exam.title}</h3>
                    <p>{exam.description || "No description provided."}</p>
                    <div className="exam-meta">
                      <span>⏱ {exam.duration_minutes} minutes</span>
                      <span>⭐ {exam.total_marks} marks</span>
                    </div>
                    {isAdmin ? (
                      <button
                        className="primary-button"
                        onClick={() => {
                          setSelectedExam(exam);
                          setPage("manage-questions");
                        }}
                      >
                        Manage questions
                      </button>
                    ) : (
                      <button
                        className="primary-button"
                        onClick={() => openExam(exam)}
                      >
                        Start examination
                      </button>
                    )}
                  </article>
                ))}
              </div>
            )}
          </section>
        )}

        {page === "admin" && isAdmin && (
          <section>
            <PageHeading
              title="Administrator Dashboard"
              subtitle="Create and manage examinations."
            />

            <div className="panel">
              <h2>Create a new examination</h2>
              <form onSubmit={handleCreateExam} className="form-grid">
                <label>
                  Exam title
                  <input
                    required
                    maxLength={255}
                    value={examForm.title}
                    onChange={(e) =>
                      setExamForm({
                        ...examForm,
                        title: e.target.value,
                      })
                    }
                    placeholder="Example: Java Programming Test"
                  />
                </label>

                <label>
                  Duration in minutes
                  <input
                    type="number"
                    min="1"
                    max="600"
                    required
                    value={examForm.duration_minutes}
                    onChange={(e) =>
                      setExamForm({
                        ...examForm,
                        duration_minutes: e.target.value,
                      })
                    }
                  />
                </label>

                <label className="wide">
                  Description
                  <textarea
                    value={examForm.description}
                    onChange={(e) =>
                      setExamForm({
                        ...examForm,
                        description: e.target.value,
                      })
                    }
                    placeholder="Enter examination details"
                  />
                </label>

                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={examForm.is_published}
                    onChange={(e) =>
                      setExamForm({
                        ...examForm,
                        is_published: e.target.checked,
                      })
                    }
                  />
                  Publish this exam immediately
                </label>

                <div className="wide">
                  <button className="primary-button" type="submit">
                    Create examination
                  </button>
                </div>
              </form>
            </div>

            <div className="panel">
              <h2>Existing examinations</h2>
              <ExamTable
                exams={exams}
                onManage={(exam) => {
                  setSelectedExam(exam);
                  setPage("manage-questions");
                }}
              />
            </div>
          </section>
        )}

        {page === "manage-questions" && isAdmin && selectedExam && (
          <section>
            <PageHeading
              title="Manage Questions"
              subtitle={`Adding questions to ${selectedExam.title}`}
            />

            <button
              className="secondary-button"
              onClick={() => showPage("admin")}
            >
              ← Back to Admin
            </button>

            <div className="panel">
              <h2>Add multiple-choice question</h2>

              <form onSubmit={handleAddQuestion} className="form-grid">
                <label className="wide">
                  Question
                  <textarea
                    required
                    value={questionForm.question_text}
                    onChange={(e) =>
                      setQuestionForm({
                        ...questionForm,
                        question_text: e.target.value,
                      })
                    }
                  />
                </label>

                {["a", "b", "c", "d"].map((option) => (
                  <label key={option}>
                    Option {option.toUpperCase()}
                    <input
                      required
                      value={questionForm[`option_${option}`]}
                      onChange={(e) =>
                        setQuestionForm({
                          ...questionForm,
                          [`option_${option}`]: e.target.value,
                        })
                      }
                    />
                  </label>
                ))}

                <label>
                  Correct option
                  <select
                    value={questionForm.correct_option}
                    onChange={(e) =>
                      setQuestionForm({
                        ...questionForm,
                        correct_option: e.target.value,
                      })
                    }
                  >
                    <option value="A">Option A</option>
                    <option value="B">Option B</option>
                    <option value="C">Option C</option>
                    <option value="D">Option D</option>
                  </select>
                </label>

                <label>
                  Marks
                  <input
                    type="number"
                    min="1"
                    max="100"
                    required
                    value={questionForm.marks}
                    onChange={(e) =>
                      setQuestionForm({
                        ...questionForm,
                        marks: e.target.value,
                      })
                    }
                  />
                </label>

                <div className="wide">
                  <button className="primary-button" type="submit">
                    Add question
                  </button>
                </div>
              </form>
            </div>
          </section>
        )}

        {page === "take-exam" && selectedExam && (
          <section>
            <PageHeading
              title={selectedExam.title}
              subtitle={`${selectedExam.duration_minutes} minutes · ${selectedExam.total_marks} marks`}
            />

            {submission ? (
              <div className="result-card">
                <div className="result-icon">🏆</div>
                <h2>Examination completed!</h2>
                <p>Your answers have been submitted successfully.</p>
                <div className="score">
                  {submission.score} / {submission.total_marks}
                </div>
                <h3>{submission.percentage}%</h3>
                <p>
                  Correct answers: {submission.correct_answers} of{" "}
                  {submission.total_questions}
                </p>
                <button
                  className="primary-button"
                  onClick={() => showPage("results")}
                >
                  View my results
                </button>
              </div>
            ) : questions.length === 0 ? (
              <EmptyState message="This examination has no questions yet." />
            ) : (
              <form onSubmit={handleSubmitExam}>
                {questions.map((question, index) => (
                  <article className="question-card" key={question.id}>
                    <h3>
                      Question {index + 1}: {question.question_text}
                    </h3>
                    <p className="muted">{question.marks} marks</p>

                    {["A", "B", "C", "D"].map((option) => (
                      <label className="answer-option" key={option}>
                        <input
                          type="radio"
                          name={`question-${question.id}`}
                          checked={answers[question.id] === option}
                          onChange={() =>
                            setAnswers({
                              ...answers,
                              [question.id]: option,
                            })
                          }
                        />
                        <span>
                          {option}. {question[`option_${option.toLowerCase()}`]}
                        </span>
                      </label>
                    ))}
                  </article>
                ))}

                <button className="primary-button submit-button" type="submit">
                  Submit examination
                </button>
              </form>
            )}
          </section>
        )}

        {page === "results" && !isAdmin && (
          <section>
            <PageHeading
              title="My Results"
              subtitle="Your examination performance."
            />
            <ResultsTable results={results} />
          </section>
        )}

        {page === "admin-results" && isAdmin && (
          <section>
            <PageHeading
              title="All Examination Results"
              subtitle="Recent student submissions."
            />
            <AdminResultsTable
              results={adminData?.recent_results || []}
            />
          </section>
        )}
      </main>

      <footer>
        Online Examination System · React + FastAPI + Keycloak
      </footer>
    </div>
  );
}

function PageHeading({ title, subtitle }) {
  return (
    <div className="page-heading">
      <h1>{title}</h1>
      <p>{subtitle}</p>
    </div>
  );
}

function StatCard({ title, value, icon }) {
  return (
    <div className="stat-card">
      <span>{icon}</span>
      <div>
        <p>{title}</p>
        <h2>{value}</h2>
      </div>
    </div>
  );
}

function EmptyState({ message }) {
  return <div className="empty-state">{message}</div>;
}

function ExamTable({ exams, onManage }) {
  if (!exams.length) return <EmptyState message="No exams found." />;

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Duration</th>
            <th>Marks</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {exams.map((exam) => (
            <tr key={exam.id}>
              <td>{exam.id}</td>
              <td>{exam.title}</td>
              <td>{exam.duration_minutes} min</td>
              <td>{exam.total_marks}</td>
              <td>{exam.is_published ? "Published" : "Draft"}</td>
              <td>
                <button
                  className="small-button"
                  onClick={() => onManage(exam)}
                >
                  Questions
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ResultsTable({ results }) {
  if (!results.length) {
    return <EmptyState message="You have not submitted any examinations yet." />;
  }

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Exam</th>
            <th>Score</th>
            <th>Total Marks</th>
            <th>Status</th>
            <th>Submitted</th>
          </tr>
        </thead>
        <tbody>
          {results.map((result) => (
            <tr key={result.id}>
              <td>{result.exam_title || `Exam ${result.exam_id}`}</td>
              <td>{result.score}</td>
              <td>{result.total_marks}</td>
              <td>{result.status}</td>
              <td>
                {result.submitted_at
                  ? new Date(result.submitted_at).toLocaleString()
                  : "-"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AdminResultsTable({ results }) {
  if (!results.length) {
    return <EmptyState message="No student results are available yet." />;
  }

  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Student</th>
            <th>Exam</th>
            <th>Score</th>
            <th>Total Marks</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {results.map((result) => (
            <tr key={result.id}>
              <td>{result.username || "Student"}</td>
              <td>{result.exam_title || "-"}</td>
              <td>{result.score}</td>
              <td>{result.total_marks}</td>
              <td>{result.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
