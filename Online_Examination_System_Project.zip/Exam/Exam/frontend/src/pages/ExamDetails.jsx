export default function ExamDetails({ exam, onNavigate }) {
  if (!exam) {
    return (
      <section className="page">
        <h1>Exam Details</h1>
        <div className="empty-state">
          <p>No exam was selected.</p>
          <button onClick={() => onNavigate?.("exams")}>
            Back to Exams
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="page">
      <button
        className="secondary-button"
        onClick={() => onNavigate?.("exams")}
      >
        ← Back to Exams
      </button>

      <article className="details-card">
        <h1>{exam.title}</h1>

        <p className="muted-text">Examination details</p>

        <div className="detail-row">
          <strong>Exam ID</strong>
          <span>{exam.id ?? "Not available"}</span>
        </div>

        <div className="detail-row">
          <strong>Description</strong>
          <span>{exam.description || "No description provided."}</span>
        </div>

        <div className="notice-message">
          <strong>Exam attempt not configured yet.</strong>
          <p>
            The current backend supports exam listing and administration.
            Questions, exam attempts, answer submission, and automatic
            scoring must be implemented before you can take this exam.
          </p>
        </div>
      </article>
    </section>
  );
}
