import { useCallback, useEffect, useState } from "react";
import { getAdminDashboard, getExams, createExam } from "../api";

export default function AdminDashboard({ keycloak }) {
  const [authorized, setAuthorized] = useState(false);
  const [checkingAccess, setCheckingAccess] = useState(true);
  const [exams, setExams] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [loadingExams, setLoadingExams] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const loadExams = useCallback(async () => {
    setLoadingExams(true);

    try {
      const data = await getExams(keycloak);
      setExams(Array.isArray(data) ? data : []);
    } catch (err) {
      setError(err.message || "Unable to load exams.");
    } finally {
      setLoadingExams(false);
    }
  }, [keycloak]);

  useEffect(() => {
    let active = true;

    async function checkAdminAccess() {
      setCheckingAccess(true);
      setError("");

      try {
        // The backend must enforce admin role authorization here.
        await getAdminDashboard(keycloak);

        if (!active) return;

        setAuthorized(true);

        const data = await getExams(keycloak);

        if (active) {
          setExams(Array.isArray(data) ? data : []);
        }
      } catch (err) {
        if (active) {
          setAuthorized(false);
          setError(err.message || "Admin access denied.");
        }
      } finally {
        if (active) setCheckingAccess(false);
      }
    }

    if (keycloak?.authenticated) {
      checkAdminAccess();
    } else {
      setAuthorized(false);
      setCheckingAccess(false);
      setError("Please log in to continue.");
    }

    return () => {
      active = false;
    };
  }, [keycloak]);

  async function handleCreateExam(event) {
    event.preventDefault();
    setError("");
    setMessage("");

    const trimmedTitle = title.trim();
    const trimmedDescription = description.trim();

    if (!trimmedTitle) {
      setError("Please enter an exam title.");
      return;
    }

    setSaving(true);

    try {
      await createExam(keycloak, {
        title: trimmedTitle,
        description: trimmedDescription,
      });

      setTitle("");
      setDescription("");
      setMessage("Exam created successfully.");

      await loadExams();
    } catch (err) {
      setError(err.message || "Unable to create exam.");
    } finally {
      setSaving(false);
    }
  }

  if (checkingAccess) {
    return (
      <section className="page">
        <p>Checking administrator access...</p>
      </section>
    );
  }

  if (!authorized) {
    return (
      <section className="page">
        <h1>Administrator Dashboard</h1>

        <div className="error-message">
          <strong>Access denied</strong>
          <p>
            This page requires the admin role. Sign in with an
            administrator account and try again.
          </p>
          {error && <p>{error}</p>}
        </div>
      </section>
    );
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <h1>Administrator Dashboard</h1>
          <p>Create and manage examinations.</p>
        </div>

        <span className="status-badge">Admin access verified</span>
      </div>

      {error && <div className="error-message">{error}</div>}
      {message && <div className="success-message">{message}</div>}

      <div className="admin-layout">
        <article className="details-card">
          <h2>Create New Exam</h2>

          <form onSubmit={handleCreateExam}>
            <label htmlFor="exam-title">Exam title</label>
            <input
              id="exam-title"
              type="text"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="Example: Python Basics"
              required
            />

            <label htmlFor="exam-description">Description</label>
            <textarea
              id="exam-description"
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              placeholder="Enter the exam description"
              rows={4}
            />

            <button type="submit" disabled={saving}>
              {saving ? "Creating..." : "Create Exam"}
            </button>
          </form>
        </article>

        <article className="details-card">
          <div className="page-header">
            <h2>Existing Exams</h2>

            <button
              className="secondary-button"
              type="button"
              onClick={loadExams}
              disabled={loadingExams}
            >
              {loadingExams ? "Refreshing..." : "Refresh"}
            </button>
          </div>

          {exams.length === 0 && !loadingExams && (
            <p>No exams found.</p>
          )}

          {exams.map((exam) => (
            <div className="exam-list-item" key={exam.id}>
              <strong>{exam.title}</strong>
              <p>{exam.description || "No description provided."}</p>
              <small>Exam ID: {exam.id}</small>
            </div>
          ))}
        </article>
      </div>
    </section>
  );
}
