import { useEffect, useState } from "react";
import { getMyProfile, getExams } from "../api";

export default function Dashboard({ keycloak, onNavigate }) {
  const [profile, setProfile] = useState(null);
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    async function loadDashboard() {
      setLoading(true);
      setError("");

      try {
        const [profileData, examData] = await Promise.all([
          getMyProfile(keycloak),
          getExams(keycloak),
        ]);

        if (!active) return;

        setProfile(profileData);
        setExams(Array.isArray(examData) ? examData : []);
      } catch (err) {
        if (active) {
          setError(err.message || "Unable to load dashboard.");
        }
      } finally {
        if (active) setLoading(false);
      }
    }

    if (keycloak?.authenticated) {
      loadDashboard();
    } else {
      setLoading(false);
      setError("Please log in to view your dashboard.");
    }

    return () => {
      active = false;
    };
  }, [keycloak]);

  const displayName =
    profile?.full_name ||
    profile?.name ||
    profile?.email ||
    keycloak?.tokenParsed?.preferred_username ||
    "Student";

  if (loading) {
    return <section className="page"><p>Loading dashboard...</p></section>;
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <h1>Dashboard</h1>
          <p>Welcome back, {displayName}!</p>
        </div>
        <span className="status-badge">Logged in</span>
      </div>

      {error && <div className="error-message">{error}</div>}

      <div className="dashboard-grid">
        <article className="dashboard-card">
          <h2>Available Exams</h2>
          <p className="large-number">{exams.length}</p>
          <p>Exams currently available in the system.</p>
          <button onClick={() => onNavigate?.("exams")}>
            View Exams
          </button>
        </article>

        <article className="dashboard-card">
          <h2>My Results</h2>
          <p>View your recorded examination results.</p>
          <button
            className="secondary-button"
            onClick={() => onNavigate?.("results")}
          >
            View Results
          </button>
        </article>

        <article className="dashboard-card">
          <h2>My Account</h2>
          <p><strong>Name:</strong> {displayName}</p>
          <p>
            <strong>Email:</strong>{" "}
            {profile?.email || keycloak?.tokenParsed?.email || "Not available"}
          </p>
        </article>
      </div>
    </section>
  );
}
