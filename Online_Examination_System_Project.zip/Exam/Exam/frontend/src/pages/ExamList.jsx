import { useCallback, useEffect, useState } from "react";
import { getExams } from "../api";
import ExamCard from "../components/ExamCard";

export default function ExamList({ keycloak, onNavigate }) {
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadExams = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await getExams(keycloak);

      if (!Array.isArray(data)) {
        throw new Error("The backend returned an unexpected exam list.");
      }

      setExams(data);
    } catch (err) {
      setError(err?.message || "Unable to load exams.");
    } finally {
      setLoading(false);
    }
  }, [keycloak]);

  useEffect(() => {
    loadExams();
  }, [loadExams]);

  function handleViewDetails(exam) {
    if (typeof onNavigate === "function") {
      onNavigate("exam-details", exam);
    }
  }

  return (
    <section className="page exam-list-page">
      <div className="page-header">
        <div>
          <p className="section-eyebrow">LEARNING AND ASSESSMENT</p>
          <h1>Available Exams</h1>
          <p className="page-description">
            Browse the examinations available to your account.
          </p>
        </div>

        <button
          type="button"
          className="secondary-button"
          onClick={loadExams}
          disabled={loading}
        >
          {loading ? "Loading..." : "Refresh Exams"}
        </button>
      </div>

      {!loading && !error && (
        <div className="exam-count">
          {exams.length} {exams.length === 1 ? "exam" : "exams"} found
        </div>
      )}

      {loading && (
        <div className="state-card" role="status">
          <div className="loading-spinner" aria-hidden="true" />
          <h2>Loading exams...</h2>
          <p>Please wait while we contact the server.</p>
        </div>
      )}

      {!loading && error && (
        <div className="state-card error-state" role="alert">
          <h2>Unable to load exams</h2>
          <p>{error}</p>
          <button type="button" onClick={loadExams}>
            Try Again
          </button>
        </div>
      )}

      {!loading && !error && exams.length === 0 && (
        <div className="state-card">
          <h2>No exams available</h2>
          <p>
            No examinations were found. Please check again later or
            contact your administrator.
          </p>
        </div>
      )}

      {!loading && !error && exams.length > 0 && (
        <div className="exam-grid">
          {exams.map((exam, index) => (
            <ExamCard
              key={exam.id ?? `exam-${index}`}
              exam={exam}
              onViewDetails={handleViewDetails}
            />
          ))}
        </div>
      )}
    </section>
  );
}
