import { useCallback, useEffect, useState } from "react";
import { getMyResults } from "../api";

export default function MyResults({ keycloak }) {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const loadResults = useCallback(async () => {
    setLoading(true);
    setError("");

    try {
      const data = await getMyResults(keycloak);

      // Support either a plain array or an object containing a results array.
      const resultList = Array.isArray(data)
        ? data
        : Array.isArray(data?.results)
          ? data.results
          : [];

      setResults(resultList);
    } catch (err) {
      setError(err.message || "Unable to load your results.");
    } finally {
      setLoading(false);
    }
  }, [keycloak]);

  useEffect(() => {
    loadResults();
  }, [loadResults]);

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <h1>My Results</h1>
          <p>Review your recorded examination results.</p>
        </div>

        <button className="secondary-button" onClick={loadResults}>
          Refresh
        </button>
      </div>

      {loading && <p>Loading your results...</p>}

      {error && <div className="error-message">{error}</div>}

      {!loading && !error && results.length === 0 && (
        <div className="empty-state">
          <h2>No results available</h2>
          <p>
            Your results will appear here after the backend records
            an examination result.
          </p>
        </div>
      )}

      {!loading && !error && results.length > 0 && (
        <div className="table-container">
          <table className="results-table">
            <thead>
              <tr>
                <th>Result ID</th>
                <th>Exam ID</th>
                <th>Score</th>
                <th>Status</th>
              </tr>
            </thead>

            <tbody>
              {results.map((result, index) => (
                <tr key={result.id ?? index}>
                  <td>{result.id ?? "—"}</td>
                  <td>{result.exam_id ?? "—"}</td>
                  <td>
                    {result.score !== undefined && result.score !== null
                      ? result.score
                      : "Not available"}
                  </td>
                  <td>{result.status ?? "Recorded"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
