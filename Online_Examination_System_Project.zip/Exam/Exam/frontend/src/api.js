
const API_BASE_URL = "http://localhost:8000";

export async function apiRequest(keycloak, path, options = {}) {
  if (!keycloak?.authenticated) {
    throw new Error("Please log in first.");
  }

  try {
    await keycloak.updateToken(30);
  } catch {
    throw new Error("Your session has expired. Please log in again.");
  }

  const headers = {
    Accept: "application/json",
    Authorization: `Bearer ${keycloak.token}`,
    ...options.headers,
  };

  if (options.body && !headers["Content-Type"]) {
    headers["Content-Type"] = "application/json";
  }

  let response;

  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers,
    });
  } catch {
    throw new Error(
      "Cannot connect to the backend. Check that FastAPI is running on port 8000."
    );
  }

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await response.json()
    : await response.text();

  if (!response.ok) {
    const message =
      typeof data === "string"
        ? data
        : data?.detail || data?.message || `Request failed: ${response.status}`;

    throw new Error(
      typeof message === "string" ? message : JSON.stringify(message)
    );
  }

  return data;
}

export function getProfile(keycloak) {
  return apiRequest(keycloak, "/api/me");
}

export function getExams(keycloak) {
  return apiRequest(keycloak, "/api/exams");
}

export function createExam(keycloak, exam) {
  return apiRequest(keycloak, "/api/exams", {
    method: "POST",
    body: JSON.stringify(exam),
  });
}

export function getQuestions(keycloak, examId) {
  return apiRequest(keycloak, `/api/exams/${examId}/questions`);
}

export function addQuestion(keycloak, examId, question) {
  return apiRequest(keycloak, `/api/exams/${examId}/questions`, {
    method: "POST",
    body: JSON.stringify(question),
  });
}

export function deleteQuestion(keycloak, questionId) {
  return apiRequest(keycloak, `/api/questions/${questionId}`, {
    method: "DELETE",
  });
}

export function submitExam(keycloak, examId, answers) {
  return apiRequest(keycloak, `/api/exams/${examId}/submit`, {
    method: "POST",
    body: JSON.stringify({ answers }),
  });
}

export function getMyResults(keycloak) {
  return apiRequest(keycloak, "/api/results/me");
}

export function getAdminDashboard(keycloak) {
  return apiRequest(keycloak, "/api/admin");
}
