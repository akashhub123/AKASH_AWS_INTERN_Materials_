export default function ProtectedRoute({
  keycloak,
  requiredRole,
  children,
}) {
  if (!keycloak?.authenticated) {
    return (
      <section className="page">
        <h2>Login Required</h2>
        <p>Please log in to access this page.</p>
      </section>
    );
  }

  if (requiredRole) {
    const roles = keycloak.tokenParsed?.realm_access?.roles ?? [];

    if (!roles.includes(requiredRole)) {
      return (
        <section className="page">
          <h2>Access Denied</h2>
          <p>
            You do not have the required role to access this page.
          </p>
        </section>
      );
    }
  }

  return children;
}
