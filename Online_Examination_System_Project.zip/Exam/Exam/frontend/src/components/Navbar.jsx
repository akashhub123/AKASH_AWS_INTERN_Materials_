export default function Navbar({
  keycloak,
  currentPage,
  onNavigate,
  onLogout,
}) {
  const roles = keycloak?.tokenParsed?.realm_access?.roles ?? [];
  const isAdmin = roles.includes("admin");

  const username =
    keycloak?.tokenParsed?.preferred_username ||
    keycloak?.tokenParsed?.name ||
    "User";

  const links = [
    { id: "dashboard", label: "Dashboard" },
    { id: "exams", label: "Exams" },
    { id: "results", label: "My Results" },
  ];

  if (isAdmin) {
    links.push({ id: "admin", label: "Admin" });
  }

  return (
    <header className="navbar">
      <button
        type="button"
        className="brand-button"
        onClick={() => onNavigate("dashboard")}
      >
        Online Examination System
      </button>

      <nav className="nav-links" aria-label="Main navigation">
        {links.map((link) => (
          <button
            key={link.id}
            type="button"
            className={currentPage === link.id ? "active" : ""}
            aria-current={currentPage === link.id ? "page" : undefined}
            onClick={() => onNavigate(link.id)}
          >
            {link.label}
          </button>
        ))}
      </nav>

      <div className="user-controls">
        <span className="username">{username}</span>

        <button
          type="button"
          className="secondary-button"
          onClick={onLogout}
        >
          Logout
        </button>
      </div>
    </header>
  );
}
