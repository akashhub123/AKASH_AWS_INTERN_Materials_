export default function ExamCard({ exam, onViewDetails }) {
  if (!exam) {
    return null;
  }

  return (
    <article className="exam-card">
      <div className="exam-card-content">
        <span className="exam-label">EXAMINATION</span>

        <h2>{exam.title || "Untitled Exam"}</h2>

        <p className="exam-description">
          {exam.description || "No description provided for this exam."}
        </p>

        <p className="exam-id">
          Exam ID: {exam.id ?? "Not available"}
        </p>
      </div>

      <div className="exam-card-footer">
        <button
          type="button"
          onClick={() => onViewDetails?.(exam)}
          disabled={!onViewDetails}
        >
          View Details
        </button>
      </div>
    </article>
  );
}
