from decimal import Decimal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ExamCreate(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    description: str = ""
    duration_minutes: int = Field(gt=0, le=600)


class ExamResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    description: str
    duration_minutes: int


class UserResponse(BaseModel):
    id: UUID
    keycloak_user_id: str
    email: str
    phone: str | None
    full_name: str | None
    roles: list[str]


class ResultResponse(BaseModel):
    id: int
    exam_id: int
    score: Decimal