import os
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application configuration loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # PostgreSQL connection string.
    database_url: str = (
        "postgresql://postgres:postgres@postgres:5432/examdb"
    )

    # Keycloak configuration.
    keycloak_issuer: str = (
        "http://localhost:8080/realms/exam-system"
    )
    keycloak_internal_url: str = "http://keycloak:8080"

    # Frontend origin allowed to access the API.
    cors_origins: str = "http://localhost:3000"

    # Development configuration only.
    # Your authentication code must still validate tokens properly.
    verify_aud: bool = False

    app_name: str = "Online Examination System"
    debug: bool = False

    @property
    def allowed_origins(self) -> list[str]:
        """Convert comma-separated frontend origins into a list."""
        return [
            origin.strip()
            for origin in self.cors_origins.split(",")
            if origin.strip()
        ]


@lru_cache
def get_settings() -> Settings:
    """Return a cached settings instance."""
    return Settings()


settings = get_settings()
