from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_admin
from app.api import repositories as repo
from app.database import get_db

router = APIRouter(prefix="/api/admin", tags=["Administration"])


@router.get("")
def admin_dashboard(
    claims: dict = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    exams = repo.list_exams(db)
    results = repo.list_all_results(db)

    return {
        "message": "Administrator dashboard",
        "statistics": {
            "users": repo.count_users(db),
            "exams": repo.count_exams(db),
            "questions": repo.count_questions(db),
            "results": repo.count_results(db),
        },
        "exams": [
            {
                "id": exam.id,
                "title": exam.title,
                "description": exam.description,
                "duration_minutes": exam.duration_minutes,
                "total_marks": exam.total_marks,
                "is_published": exam.is_published,
                "created_at": exam.created_at,
            }
            for exam in exams
        ],
        "recent_results": [
            {
                "id": result.id,
                "username": result.user.username if result.user else None,
                "exam_title": result.exam.title if result.exam else None,
                "score": float(result.score),
                "total_marks": float(result.total_marks),
                "status": result.status,
                "submitted_at": result.submitted_at,
            }
            for result in results[:10]
        ],
    }
