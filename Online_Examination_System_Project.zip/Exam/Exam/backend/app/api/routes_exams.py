from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_admin, get_current_user
from app.api import repositories as repo
from app.api.services import create_exam_service
from app.database import get_db

router = APIRouter(prefix="/api/exams", tags=["Exams"])


class ExamCreate(BaseModel):
    title: str = Field(min_length=1, max_length=255)
    description: str | None = None
    duration_minutes: int = Field(default=30, ge=1, le=600)
    is_published: bool = False


def exam_to_dict(exam):
    return {
        "id": exam.id,
        "title": exam.title,
        "description": exam.description,
        "duration_minutes": exam.duration_minutes,
        "total_marks": exam.total_marks,
        "is_published": exam.is_published,
        "created_by": exam.created_by,
        "created_at": exam.created_at,
    }


@router.get("")
def list_exams(
    claims: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Administrators can see all exams. Students see published exams only.
    roles = (claims.get("realm_access") or {}).get("roles", [])
    exams = repo.list_exams(db)

    if "admin" not in roles:
        exams = [exam for exam in exams if exam.is_published]

    return [exam_to_dict(exam) for exam in exams]


@router.get("/{exam_id}")
def get_exam(
    exam_id: int,
    claims: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    exam = repo.get_exam_by_id(db, exam_id)

    if exam is None:
        raise HTTPException(status_code=404, detail="Exam not found.")

    roles = (claims.get("realm_access") or {}).get("roles", [])
    if not exam.is_published and "admin" not in roles:
        raise HTTPException(status_code=404, detail="Exam not found.")

    return exam_to_dict(exam)


@router.post("", status_code=status.HTTP_201_CREATED)
def create_exam(
    payload: ExamCreate,
    claims: dict = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    exam = create_exam_service(
        db=db,
        claims=claims,
        title=payload.title,
        description=payload.description,
        duration_minutes=payload.duration_minutes,
        is_published=payload.is_published,
    )
    return exam_to_dict(exam)
