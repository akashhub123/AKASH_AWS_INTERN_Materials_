from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.models import AppUser, Exam, ExamResult, Question


# -------------------------
# Users
# -------------------------

def get_user_by_keycloak_id(
    db: Session, keycloak_id: str
) -> AppUser | None:
    return db.scalar(
        select(AppUser).where(AppUser.keycloak_id == keycloak_id)
    )


def get_user_by_id(db: Session, user_id: int) -> AppUser | None:
    return db.get(AppUser, user_id)


def create_user(db: Session, user: AppUser) -> AppUser:
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


# -------------------------
# Exams
# -------------------------

def get_exam_by_id(
    db: Session, exam_id: int, include_questions: bool = False
) -> Exam | None:
    statement = select(Exam).where(Exam.id == exam_id)

    if include_questions:
        statement = statement.options(selectinload(Exam.questions))

    return db.scalar(statement)


def list_exams(db: Session) -> list[Exam]:
    statement = select(Exam).order_by(Exam.id.desc())
    return list(db.scalars(statement).all())


def create_exam(db: Session, exam: Exam) -> Exam:
    db.add(exam)
    db.commit()
    db.refresh(exam)
    return exam


def delete_exam(db: Session, exam: Exam) -> None:
    db.delete(exam)
    db.commit()


def count_exams(db: Session) -> int:
    return db.scalar(select(func.count()).select_from(Exam)) or 0


# -------------------------
# Questions
# -------------------------

def get_question_by_id(
    db: Session, question_id: int
) -> Question | None:
    return db.get(Question, question_id)


def list_questions_for_exam(
    db: Session, exam_id: int
) -> list[Question]:
    statement = (
        select(Question)
        .where(Question.exam_id == exam_id)
        .order_by(Question.id)
    )
    return list(db.scalars(statement).all())


def create_question(db: Session, question: Question) -> Question:
    db.add(question)
    db.flush()
    return question


def delete_question(db: Session, question: Question) -> None:
    db.delete(question)
    db.commit()


def update_exam_total_marks(db: Session, exam_id: int) -> int:
    total = db.scalar(
        select(func.coalesce(func.sum(Question.marks), 0)).where(
            Question.exam_id == exam_id
        )
    )
    exam = db.get(Exam, exam_id)

    if exam is None:
        return 0

    exam.total_marks = int(total or 0)
    db.commit()
    db.refresh(exam)
    return exam.total_marks


# -------------------------
# Results
# -------------------------

def create_result(db: Session, result: ExamResult) -> ExamResult:
    db.add(result)
    db.commit()
    db.refresh(result)
    return result


def list_results_for_user(
    db: Session, user_id: int
) -> list[ExamResult]:
    statement = (
        select(ExamResult)
        .options(selectinload(ExamResult.exam))
        .where(ExamResult.user_id == user_id)
        .order_by(ExamResult.created_at.desc())
    )
    return list(db.scalars(statement).all())


def list_all_results(db: Session) -> list[ExamResult]:
    statement = (
        select(ExamResult)
        .options(
            selectinload(ExamResult.user),
            selectinload(ExamResult.exam),
        )
        .order_by(ExamResult.created_at.desc())
    )
    return list(db.scalars(statement).all())


def count_users(db: Session) -> int:
    return db.scalar(select(func.count()).select_from(AppUser)) or 0


def count_questions(db: Session) -> int:
    return db.scalar(select(func.count()).select_from(Question)) or 0


def count_results(db: Session) -> int:
    return db.scalar(select(func.count()).select_from(ExamResult)) or 0
