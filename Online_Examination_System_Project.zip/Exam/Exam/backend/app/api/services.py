from datetime import datetime, timezone
from typing import Any

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models import AppUser, Exam, ExamResult, Question
from app.api import repositories as repo


def sync_user_from_keycloak(
    db: Session, claims: dict[str, Any]
) -> AppUser:
    """Create or update the local database record for a Keycloak user."""

    keycloak_id = claims.get("sub")
    if not keycloak_id:
        raise HTTPException(
            status_code=401,
            detail="The access token does not contain a user ID.",
        )

    username = (
        claims.get("preferred_username")
        or claims.get("email")
        or keycloak_id
    )
    email = claims.get("email")
    full_name = claims.get("name") or claims.get("given_name") or username

    user = repo.get_user_by_keycloak_id(db, keycloak_id)

    if user is None:
        # Avoid creating duplicate local users if an email is already linked
        # to a different Keycloak account.
        if email:
            from sqlalchemy import select

            existing_email_user = db.scalar(
                select(AppUser).where(AppUser.email == email)
            )
            if existing_email_user:
                raise HTTPException(
                    status_code=409,
                    detail=(
                        "This email is already linked to another local "
                        "account. Ask an administrator to review it."
                    ),
                )

        user = AppUser(
            keycloak_id=keycloak_id,
            username=username,
            email=email,
            full_name=full_name,
        )
        db.add(user)
    else:
        user.username = username
        user.email = email
        user.full_name = full_name

    try:
        db.commit()
        db.refresh(user)
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=409,
            detail=(
                "Could not save your profile. Your username or email "
                "may already be in use."
            ),
        )

    return user


def create_exam_service(
    db: Session,
    claims: dict[str, Any],
    title: str,
    description: str | None,
    duration_minutes: int,
    is_published: bool,
) -> Exam:
    """Create an exam after validating the input."""

    clean_title = title.strip()
    if not clean_title:
        raise HTTPException(status_code=422, detail="Exam title is required.")

    exam = Exam(
        title=clean_title,
        description=description,
        duration_minutes=duration_minutes,
        total_marks=0,
        is_published=is_published,
        created_by=claims.get("sub"),
    )

    return repo.create_exam(db, exam)


def add_question_service(
    db: Session,
    exam_id: int,
    question_text: str,
    option_a: str,
    option_b: str,
    option_c: str,
    option_d: str,
    correct_option: str,
    marks: int,
) -> Question:
    """Add a multiple-choice question and update the exam's total marks."""

    exam = repo.get_exam_by_id(db, exam_id)
    if exam is None:
        raise HTTPException(status_code=404, detail="Exam not found.")

    answer = correct_option.strip().upper()
    if answer not in {"A", "B", "C", "D"}:
        raise HTTPException(
            status_code=422,
            detail="correct_option must be A, B, C, or D.",
        )

    if marks < 1:
        raise HTTPException(
            status_code=422, detail="Question marks must be at least 1."
        )

    question = Question(
        exam_id=exam_id,
        question_text=question_text.strip(),
        option_a=option_a.strip(),
        option_b=option_b.strip(),
        option_c=option_c.strip(),
        option_d=option_d.strip(),
        correct_option=answer,
        marks=marks,
    )

    try:
        repo.create_question(db, question)
        repo.update_exam_total_marks(db, exam_id)
        db.refresh(question)
        return question
    except Exception:
        db.rollback()
        raise


def submit_exam_service(
    db: Session,
    user: AppUser,
    exam_id: int,
    answers: dict[int, str],
) -> dict[str, Any]:
    """Mark answers and save one aggregate result for the exam attempt."""

    exam = repo.get_exam_by_id(db, exam_id, include_questions=True)
    if exam is None:
        raise HTTPException(status_code=404, detail="Exam not found.")

    questions = exam.questions
    if not questions:
        raise HTTPException(
            status_code=400,
            detail="This exam has no questions yet.",
        )

    question_ids = {question.id for question in questions}
    unknown_ids = set(answers.keys()) - question_ids

    if unknown_ids:
        raise HTTPException(
            status_code=422,
            detail="One or more submitted question IDs do not belong to this exam.",
        )

    score = 0
    total_marks = 0
    correct_count = 0

    for question in questions:
        total_marks += question.marks
        submitted_answer = answers.get(question.id, "")
        if (
            isinstance(submitted_answer, str)
            and submitted_answer.strip().upper()
            == question.correct_option.upper()
        ):
            score += question.marks
            correct_count += 1

    result = ExamResult(
        user_id=user.id,
        exam_id=exam.id,
        score=score,
        total_marks=total_marks,
        status="completed",
        submitted_at=datetime.now(timezone.utc),
    )

    try:
        saved_result = repo.create_result(db, result)
    except Exception:
        db.rollback()
        raise

    percentage = round((score / total_marks) * 100, 2) if total_marks else 0

    return {
        "id": saved_result.id,
        "exam_id": exam.id,
        "exam_title": exam.title,
        "score": score,
        "total_marks": total_marks,
        "percentage": percentage,
        "correct_answers": correct_count,
        "total_questions": len(questions),
        "status": saved_result.status,
        "submitted_at": saved_result.submitted_at,
    }
