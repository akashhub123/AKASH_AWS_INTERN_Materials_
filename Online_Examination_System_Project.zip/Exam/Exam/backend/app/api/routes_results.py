from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.api import repositories as repo
from app.api.services import (
    submit_exam_service,
    sync_user_from_keycloak,
)
from app.database import get_db

router = APIRouter(tags=["Results"])


class ExamSubmission(BaseModel):
    answers: dict[int, str] = Field(default_factory=dict)


@router.get("/api/results/me")
def get_my_results(
    claims: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    user = sync_user_from_keycloak(db, claims)
    results = repo.list_results_for_user(db, user.id)

    return {
        "results": [
            {
                "id": result.id,
                "exam_id": result.exam_id,
                "exam_title": result.exam.title if result.exam else None,
                "score": float(result.score),
                "total_marks": float(result.total_marks),
                "status": result.status,
                "started_at": result.started_at,
                "submitted_at": result.submitted_at,
                "created_at": result.created_at,
            }
            for result in results
        ]
    }


@router.post(
    "/api/exams/{exam_id}/submit",
    status_code=status.HTTP_201_CREATED,
)
def submit_exam(
    exam_id: int,
    payload: ExamSubmission,
    claims: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    user = sync_user_from_keycloak(db, claims)

    exam = repo.get_exam_by_id(db, exam_id)
    if exam is None or not exam.is_published:
        raise HTTPException(status_code=404, detail="Exam not found.")

    # JSON object keys arrive as strings; normalize them to integer IDs.
    normalized_answers = {}
    for question_id, answer in payload.answers.items():
        try:
            normalized_id = int(question_id)
        except (ValueError, TypeError) as exc:
            raise HTTPException(
                status_code=422,
                detail="Each answer must use a valid question ID.",
            ) from exc

        normalized_answers[normalized_id] = answer

    return submit_exam_service(
        db=db,
        user=user,
        exam_id=exam_id,
        answers=normalized_answers,
    )
