from functools import lru_cache
from typing import Any

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jwt import PyJWKClient

from app.config import settings

bearer_scheme = HTTPBearer(auto_error=False)


@lru_cache(maxsize=1)
def get_jwks_client() -> PyJWKClient:
    """Create a client for retrieving Keycloak's public signing keys."""
    base_url = settings.keycloak_internal_url.rstrip("/")
    jwks_url = (
        f"{base_url}/realms/exam-system/"
        "protocol/openid-connect/certs"
    )
    return PyJWKClient(jwks_url)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> dict[str, Any]:
    """Validate the bearer token and return its claims."""

    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Please log in.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = credentials.credentials

    try:
        signing_key = get_jwks_client().get_signing_key_from_jwt(token)

        claims = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=settings.keycloak_issuer.rstrip("/"),
            options={
                "verify_aud": settings.verify_aud,
                "require": ["exp", "iss", "sub"],
            },
        )

        if not claims.get("sub"):
            raise ValueError("Token does not contain a user ID.")

        return claims

    except Exception as exc:
        # Do not expose token-validation internals to the client.
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired access token. Please log in again.",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


def get_current_admin(
    claims: dict[str, Any] = Depends(get_current_user),
) -> dict[str, Any]:
    """Allow access only when the token contains the admin realm role."""

    realm_access = claims.get("realm_access") or {}
    roles = realm_access.get("roles") or []

    if "admin" not in roles:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrator access required.",
        )

    return claims
