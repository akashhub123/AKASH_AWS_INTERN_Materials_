from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_admin, get_current_user
from app.api import repositories as repo
from app.api.services import add_question_service
from app.database import get_db

router = APIRouter(tags=["Questions"])


class QuestionCreate(BaseModel):
    question_text: str = Field(min_length=1)
    option_a: str = Field(min_length=1)
    option_b: str = Field(min_length=1)
    option_c: str = Field(min_length=1)
    option_d: str = Field(min_length=1)
    correct_option: str = Field(pattern="^[A-Da-d]$")
    marks: int = Field(default=1, ge=1, le=100)


def question_for_student(question):
    """Never include correct_option in a student's question response."""
    return {
        "id": question.id,
        "exam_id": question.exam_id,
        "question_text": question.question_text,
        "option_a": question.option_a,
        "option_b": question.option_b,
        "option_c": question.option_c,
        "option_d": question.option_d,
        "marks": question.marks,
    }


@router.get("/api/exams/{exam_id}/questions")
def list_exam_questions(
    exam_id: int,
    claims: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    exam = repo.get_exam_by_id(db, exam_id)
    if exam is None:
        raise HTTPException(status_code=404, detail="Exam not found.")

    roles = (claims.get("realm_access") or {}).get("roles", [])
    if not exam.is_published and "admin" not in roles:
        raise HTTPException(status_code=404, detail="Exam not found.")

    questions = repo.list_questions_for_exam(db, exam_id)
    return [question_for_student(question) for question in questions]


@router.post(
    "/api/exams/{exam_id}/questions",
    status_code=status.HTTP_201_CREATED,
)
def add_exam_question(
    exam_id: int,
    payload: QuestionCreate,
    claims: dict = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    question = add_question_service(
        db=db,
        exam_id=exam_id,
        question_text=payload.question_text,
        option_a=payload.option_a,
        option_b=payload.option_b,
        option_c=payload.option_c,
        option_d=payload.option_d,
        correct_option=payload.correct_option,
        marks=payload.marks,
    )

    # Only the administrator's create response contains the correct answer.
    return {
        **question_for_student(question),
        "correct_option": question.correct_option,
    }


@router.delete("/api/questions/{question_id}")
def delete_question(
    question_id: int,
    claims: dict = Depends(get_current_admin),
    db: Session = Depends(get_db),
):
    question = repo.get_question_by_id(db, question_id)
    if question is None:
        raise HTTPException(status_code=404, detail="Question not found.")

    exam_id = question.exam_id

    try:
        db.delete(question)
        db.commit()
        repo.update_exam_total_marks(db, exam_id)
    except Exception:
        db.rollback()
        raise

    return {"message": "Question deleted successfully."}
