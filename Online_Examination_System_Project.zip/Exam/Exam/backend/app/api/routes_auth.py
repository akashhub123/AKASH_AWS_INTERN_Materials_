from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.api.services import sync_user_from_keycloak
from app.database import get_db

router = APIRouter(prefix="/api", tags=["Authentication"])


@router.get("/me")
def get_my_profile(
    claims: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    user = sync_user_from_keycloak(db, claims)

    return {
        "id": user.id,
        "keycloak_id": user.keycloak_id,
        "username": user.username,
        "email": user.email,
        "full_name": user.full_name,
        "roles": (claims.get("realm_access") or {}).get("roles", []),
        "created_at": user.created_at,
    }
