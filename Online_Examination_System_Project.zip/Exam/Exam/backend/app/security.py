import os
from functools import lru_cache

import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jwt import PyJWKClient

KEYCLOAK_ISSUER = os.environ["KEYCLOAK_ISSUER"]
KEYCLOAK_INTERNAL_URL = os.environ["KEYCLOAK_INTERNAL_URL"]
KEYCLOAK_REALM = os.environ["KEYCLOAK_REALM"]

JWKS_URL = (
    f"{KEYCLOAK_INTERNAL_URL}/realms/"
    f"{KEYCLOAK_REALM}/protocol/openid-connect/certs"
)

bearer_scheme = HTTPBearer(auto_error=False)


@lru_cache
def get_jwks_client():
    return PyJWKClient(JWKS_URL)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(
        bearer_scheme
    ),
):
    if credentials is None:
        raise HTTPException(
            status_code=401,
            detail="Bearer access token is required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        token = credentials.credentials

        signing_key = get_jwks_client().get_signing_key_from_jwt(
            token
        )

        payload = jwt.decode(
            token,
            signing_key.key,
            algorithms=["RS256"],
            issuer=KEYCLOAK_ISSUER,
            options={
                "verify_aud": False,
            },
        )

        if not payload.get("sub"):
            raise HTTPException(
                status_code=401,
                detail="Token does not contain a user ID",
            )

        return payload

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=401,
            detail="Invalid, expired, or unverifiable access token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


def require_role(required_role: str):
    def role_checker(user=Depends(get_current_user)):
        roles = user.get("realm_access", {}).get("roles", [])

        if required_role not in roles:
            raise HTTPException(
                status_code=403,
                detail=f"Role '{required_role}' is required",
            )

        return user

    return role_checker