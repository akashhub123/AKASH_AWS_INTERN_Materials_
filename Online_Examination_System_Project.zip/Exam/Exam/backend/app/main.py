from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import (
    routes_admin,
    routes_auth,
    routes_exams,
    routes_questions,
    routes_results,
)
from app.config import settings
from app.database import engine
from app.models import Base


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize database tables when the application starts."""
    Base.metadata.create_all(bind=engine)
    yield


app = FastAPI(
    title=settings.app_name,
    description=(
        "API for managing examinations, multiple-choice questions, "
        "student submissions, results, and administrator operations."
    ),
    version="1.0.0",
    lifespan=lifespan,
)


# Allow the React frontend to communicate with the backend.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Register API route modules.
app.include_router(routes_auth.router)
app.include_router(routes_admin.router)
app.include_router(routes_exams.router)
app.include_router(routes_questions.router)
app.include_router(routes_results.router)


@app.get("/", tags=["Health"])
def root():
    """Confirm that the API is running."""
    return {
        "message": "Online Examination System API is running",
        "docs": "/docs",
        "health": "/health",
    }


@app.get("/health", tags=["Health"])
def health_check():
    """Basic application health check."""
    return {
        "status": "healthy",
        "application": settings.app_name,
    }
