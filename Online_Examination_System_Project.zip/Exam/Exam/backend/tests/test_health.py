from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_root_endpoint_is_available():
    response = client.get("/")

    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/json")


def test_health_endpoint_is_available():
    response = client.get("/health")

    assert response.status_code == 200
