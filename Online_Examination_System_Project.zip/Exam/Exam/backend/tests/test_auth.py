from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_profile_requires_authentication():
    response = client.get("/api/me")

    assert response.status_code in (401, 403)


def test_profile_rejects_invalid_bearer_token():
    response = client.get(
        "/api/me",
        headers={"Authorization": "Bearer invalid-test-token"},
    )

    assert response.status_code in (401, 403)
