from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_admin_dashboard_requires_authentication():
    response = client.get("/api/admin")

    assert response.status_code in (401, 403)


def test_admin_dashboard_rejects_invalid_token():
    response = client.get(
        "/api/admin",
        headers={"Authorization": "Bearer invalid-test-token"},
    )

    assert response.status_code in (401, 403)


def test_create_exam_rejects_unauthenticated_user():
    response = client.post(
        "/api/exams",
        json={
            "title": "Unauthorized Exam",
            "description": "This request must be rejected",
        },
    )

    assert response.status_code in (401, 403)
