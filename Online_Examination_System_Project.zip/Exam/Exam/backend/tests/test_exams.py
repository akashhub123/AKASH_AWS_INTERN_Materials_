from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_list_exams_requires_authentication():
    response = client.get("/api/exams")

    assert response.status_code in (401, 403)


def test_create_exam_requires_authentication():
    exam_data = {
        "title": "Test Examination",
        "description": "An exam created during automated testing",
    }

    response = client.post("/api/exams", json=exam_data)

    assert response.status_code in (401, 403)
