
-- ============================================================
-- Online Examination System
-- PostgreSQL database schema
-- ============================================================

-- Create this schema inside the examdb database.
-- PostgreSQL creates the database itself through Docker Compose.

-- 1. Application users
-- Stores user information linked to Keycloak accounts.
CREATE TABLE IF NOT EXISTS app_users (
    id SERIAL PRIMARY KEY,
    keycloak_id VARCHAR(255) NOT NULL UNIQUE,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) UNIQUE,
    full_name VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 2. Exams
-- Stores examinations created by administrators.
CREATE TABLE IF NOT EXISTS exams (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    duration_minutes INTEGER NOT NULL DEFAULT 30
        CHECK (duration_minutes > 0),
    total_marks INTEGER NOT NULL DEFAULT 0
        CHECK (total_marks >= 0),
    is_published BOOLEAN NOT NULL DEFAULT FALSE,
    created_by VARCHAR(255),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 3. Questions
-- Each question belongs to one exam.
CREATE TABLE IF NOT EXISTS questions (
    id SERIAL PRIMARY KEY,
    exam_id INTEGER NOT NULL
        REFERENCES exams(id) ON DELETE CASCADE,
    question_text TEXT NOT NULL,
    option_a TEXT NOT NULL,
    option_b TEXT NOT NULL,
    option_c TEXT NOT NULL,
    option_d TEXT NOT NULL,
    correct_option CHAR(1) NOT NULL
        CHECK (correct_option IN ('A', 'B', 'C', 'D')),
    marks INTEGER NOT NULL DEFAULT 1
        CHECK (marks > 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 4. Exam results
-- Stores each student's exam attempt and score.
CREATE TABLE IF NOT EXISTS exam_results (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL
        REFERENCES app_users(id) ON DELETE CASCADE,
    exam_id INTEGER NOT NULL
        REFERENCES exams(id) ON DELETE CASCADE,
    score NUMERIC(8, 2) NOT NULL DEFAULT 0
        CHECK (score >= 0),
    total_marks NUMERIC(8, 2) NOT NULL DEFAULT 0
        CHECK (total_marks >= 0),
    status VARCHAR(30) NOT NULL DEFAULT 'completed'
        CHECK (status IN ('in_progress', 'completed', 'submitted')),
    started_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    submitted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Helpful indexes for common queries.
CREATE INDEX IF NOT EXISTS idx_questions_exam_id
    ON questions(exam_id);

CREATE INDEX IF NOT EXISTS idx_exam_results_user_id
    ON exam_results(user_id);

CREATE INDEX IF NOT EXISTS idx_exam_results_exam_id
    ON exam_results(exam_id);

CREATE INDEX IF NOT EXISTS idx_exams_is_published
    ON exams(is_published);

-- ============================================================
-- End of schema
-- ============================================================
